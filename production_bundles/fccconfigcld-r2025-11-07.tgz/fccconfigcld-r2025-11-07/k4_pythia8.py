import os
from Gaudi.Configuration import *
from GaudiKernel import SystemOfUnits as units

from Configurables import ApplicationMgr
ApplicationMgr().EvtSel = 'NONE'
ApplicationMgr().EvtMax = 10

from Configurables import PythiaInterface
pythia8gentool = PythiaInterface()
# Use default name for the Pythia card in iLCDirac
pythia8gentool.pythiacard = "pythia8card.cmd"
pythia8gentool.doEvtGenDecays = False
pythia8gentool.printPythiaStatistics = True

from Configurables import GenAlg
pythia8gen = GenAlg("Pythia8")
pythia8gen.SignalProvider = pythia8gentool
pythia8gen.hepmc.Path = "hepmc"
ApplicationMgr().TopAlg += [pythia8gen]

from Configurables import HepMCFileWriter
hepmc_writer = HepMCFileWriter()
hepmc_writer.hepmc.Path = "hepmc"
# Output file path set by iLCDirac
ApplicationMgr().TopAlg += [hepmc_writer]
